package ija.ija2018.homework2.common;

public interface Command {
    public boolean execute();
    public void undo();
}
